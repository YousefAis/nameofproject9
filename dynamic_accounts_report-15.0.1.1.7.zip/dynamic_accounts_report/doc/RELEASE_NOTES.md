## Module <dynamic_accounts_report>

#### 02.09.2021
#### Version 15.0.1.0.0
#### ADD
- Initial commit for Odoo 15 dynamic financial reports



#### 20.12.2021
#### Version 15.0.1.0.1
#### UPDT
- Translation issue and Calendar format issue

#### 15.01.2022
#### Version 15.0.1.0.2
#### UPDT
- Arabic Translation added

#### 01.02.2022
#### Version 15.0.1.0.3
#### UPDT AND BUGFIX
- Multi-company and Translation Update and Bugfix

#### 16.04.2022
#### Version 15.0.1.0.4
#### UPDT AND BUGFIX
- Loading issue and orderby date

#### 31.08.2022
#### Version 15.0.1.1.5
#### UPDT AND BUGFIX
- Report Bug Fix

#### 08.02.2023
#### Version 15.0.1.1.6
#### UPDT AND BUGFIX
- Report Bug Fix: Correct the currency used in the General Ledger

#### 07.03.2023
#### Version 15.0.1.1.7
#### UPDT AND BUGFIX
- Report Bug Fix: Fix the error occurs while opening the general ledger entries after filter.
